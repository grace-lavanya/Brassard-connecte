/*
 * Brassard connecté – Détection de chute
 * Auteur : Grâce Destinée LEBIKI LAVANYA
 * Description : Détecte une chute via capteur de mouvement et déclenche une alerte < 2s
 */

// ===== PINS =====
#define PIN_CAPTEUR     A0   // Capteur de mouvement / accéléromètre (valeur analogique)
#define PIN_BUZZER      8    // Buzzer actif
#define PIN_LED_ALERTE  9    // LED rouge d'alerte
#define PIN_LED_OK      10   // LED verte (état normal)
#define PIN_BOUTON      2    // Bouton de réinitialisation

// ===== SEUILS =====
#define SEUIL_CHUTE         800   // Valeur analogique correspondant à un pic de chute
#define SEUIL_IMMOBILITE    50    // Variation max considérée comme immobilité
#define DUREE_IMMOBILITE    500   // Durée d'immobilité en ms pour confirmer la chute
#define DUREE_ALERTE        5000  // Durée de l'alerte en ms

// ===== VARIABLES =====
int valeurCapteur     = 0;
int valeurPrecedente  = 0;
bool chuteDetectee    = false;
bool enAlerte         = false;
unsigned long tempsImmobilite = 0;
unsigned long tempsAlerte     = 0;

// ===== SETUP =====
void setup() {
  pinMode(PIN_BUZZER,     OUTPUT);
  pinMode(PIN_LED_ALERTE, OUTPUT);
  pinMode(PIN_LED_OK,     OUTPUT);
  pinMode(PIN_BOUTON,     INPUT_PULLUP);

  digitalWrite(PIN_LED_OK, HIGH);  // LED verte allumée au démarrage
  Serial.begin(9600);
  Serial.println("Brassard connecté prêt.");
}

// ===== LOOP =====
void loop() {
  // Lecture du bouton de reset
  if (digitalRead(PIN_BOUTON) == LOW) {
    resetAlarme();
    return;
  }

  // Si déjà en alerte, on maintient
  if (enAlerte) {
    maintienAlerte();
    return;
  }

  // Lecture capteur
  valeurCapteur = analogRead(PIN_CAPTEUR);

  // Étape 1 : Détection d'un pic (chute potentielle)
  if (!chuteDetectee && valeurCapteur > SEUIL_CHUTE) {
    chuteDetectee = true;
    tempsImmobilite = millis();
    Serial.println("Pic détecté – surveillance immobilité...");
  }

  // Étape 2 : Confirmation par immobilité prolongée
  if (chuteDetectee) {
    int variation = abs(valeurCapteur - valeurPrecedente);
    if (variation < SEUIL_IMMOBILITE) {
      if (millis() - tempsImmobilite >= DUREE_IMMOBILITE) {
        declencherAlerte();
      }
    } else {
      // Mouvement détecté → pas une chute, réinitialiser
      chuteDetectee = false;
      Serial.println("Mouvement détecté – réinitialisation.");
    }
  }

  valeurPrecedente = valeurCapteur;
  delay(50);
}

// ===== FONCTIONS =====

void declencherAlerte() {
  enAlerte = true;
  tempsAlerte = millis();
  digitalWrite(PIN_LED_OK, LOW);
  digitalWrite(PIN_LED_ALERTE, HIGH);
  tone(PIN_BUZZER, 1000);  // Bip à 1000 Hz
  Serial.println("!!! CHUTE DÉTECTÉE – ALERTE DÉCLENCHÉE !!!");
}

void maintienAlerte() {
  // Alerte automatiquement désactivée après DUREE_ALERTE
  if (millis() - tempsAlerte >= DUREE_ALERTE) {
    resetAlarme();
  }
}

void resetAlarme() {
  enAlerte = false;
  chuteDetectee = false;
  noTone(PIN_BUZZER);
  digitalWrite(PIN_LED_ALERTE, LOW);
  digitalWrite(PIN_LED_OK, HIGH);
  Serial.println("Système réinitialisé – en surveillance.");
}
