# 🦺 Brassard connecté – Détection de chute

Système embarqué de détection de chute avec alerte sonore et lumineuse, développé en C sur microcontrôleur Arduino.

## 🎯 Objectif

Détecter automatiquement une chute à partir de données d'un capteur et déclencher une alerte en moins de 2 secondes.

## ⚙️ Fonctionnement

1. Lecture continue des données du capteur (accéléromètre simulé)
2. Analyse algorithmique : détection d'un pic d'accélération suivi d'une immobilité
3. Déclenchement d'une alerte (buzzer + LED) en < 2 secondes
4. Réinitialisation manuelle via bouton

## 🛠️ Technologies

- **Langage** : C (Arduino)
- **Matériel** : Arduino Uno, capteur de mouvement, buzzer, LED, bouton poussoir
- **Outils** : Arduino IDE, câblage sur breadboard

## 📁 Structure du projet

```
brassard-connecte/
├── src/
│   └── brassard.ino      # Code principal
├── docs/
│   └── schema_circuit.png # Schéma de câblage
└── README.md
```

## 🚀 Résultats

- Temps de détection et d'alerte : **< 2 secondes**
- Taux de faux positifs réduit grâce au double critère (pic + immobilité)
